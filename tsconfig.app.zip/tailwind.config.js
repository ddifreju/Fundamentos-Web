/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}", // Ajuste se usar outra estrutura
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
